<?php

defined( '_PHP_CONGES' ) or die( 'Restricted access' );

// site et numero de version de PHP_CONGES
// ne pas toucher ces variables SVP ;-)
$config_php_conges_version="1.13";
$config_url_site_web_php_conges="http://Libertempo.tuxfamily.org";
// ne pas toucher ces variables SVP ;-)
