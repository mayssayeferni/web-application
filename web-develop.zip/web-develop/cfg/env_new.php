<?php
define('ENV', ENV_PROD);
define('LOGGER_TOKEN', '');
