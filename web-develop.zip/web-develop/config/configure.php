<?php
echo \config\Fonctions::configurationModule();
