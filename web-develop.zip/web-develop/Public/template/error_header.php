<?php
include_once 'header.php';
?>
    <body class="error">
        <header><h1 class="login-heading">Libertempo</h1></header>
        <div class="container">
            <div class="icon-header"><i class="fa fa-minus-circle"></i></div>
