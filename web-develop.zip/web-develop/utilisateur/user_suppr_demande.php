<?php

defined('_PHP_CONGES') or die('Restricted access');
echo \utilisateur\Fonctions::suppressionAbsenceModule();
