<?php

defined('_PHP_CONGES') or die('Restricted access');
echo \hr\Fonctions::pageTraitementDemandeModule($tab_type_cong, $onglet);
