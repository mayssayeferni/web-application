<?php
defined( '_PHP_CONGES' ) or die( 'Restricted access' );
?>
</div>
</div>
<footer>
<div id="bottom">
<?= BOTTOM_TEXT; ?>
</div>
</footer>
</section>
</section>
</section>
<?php
include_once 'bottom.php';
