<?php
namespace Tests\Units;

use \atoum;

/**
 * Classe racine de test
 *
 * @since  1.9
 * @author Prytoegrian <prytoegrian@protonmail.com>
 */
abstract class TestUnit extends atoum
{
}
