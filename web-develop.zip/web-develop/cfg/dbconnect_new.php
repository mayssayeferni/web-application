<?php

/*************************************************************************************************/
// VARIABLES A RENSEIGNER :
//  CONFIG ACCES A LA DATABASE
//---------------------------------------
// MySql :

defined( '_PHP_CONGES' ) or die( 'Restricted access' );

$mysql_serveur  = "localhost";
$mysql_user     = "dbconges";
$mysql_pass     = "motdepasse";
$mysql_database =  "db_conges";
