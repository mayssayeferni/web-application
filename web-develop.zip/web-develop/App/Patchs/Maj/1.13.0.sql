DROP TABLE IF EXISTS `conges_plugins`;

DROP TABLE IF EXISTS `conges_plugin_cet`;
