<?php declare(strict_types = 1);

defined('_PHP_CONGES') or die('Restricted access');
$planningId = NIL_INT;

$titre = _('hr_ajout_planning_titre');

require_once 'hr_edition_planning.php';
