DELETE FROM `conges_config` WHERE conf_nom = 'lang';
