<?php
/* Autoload */
define('ROOT_PATH', '');
define('NIL_INT', -1);
define('DS', DIRECTORY_SEPARATOR);
define('_PHP_CONGES', 1);
define('API_SYSPATH', DS . 'tmp' . DS);
require_once ROOT_PATH . 'vendor/autoload.php';
