<?php

echo \config\Fonctions::mailModule();
