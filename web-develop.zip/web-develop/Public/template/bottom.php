<?php declare(strict_types = 1);
?>

<script language="JavaScript" type="text/javascript">
<!--

if (undefined !== optionsVue) {
    optionsVue.axios = instance;
    var vm = new Vue(optionsVue);
}

//-->
</script>
<noscript>
        <font color="#FF0000"><br><br><center>'. _('javascript_obligatoires') .'</center></font><br><br>
</noscript>
</body>
</html>
