<?php
define('BOTTOM_TEXT','Libertempo 1.13 "Nooma". <a href="https://feedback.libertempo.fr/">Un bug, une idée <i class="fa fa-comment-o fa-2x"></i></a>');